package asm1;

import asm1.Student;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import asm1.StudentManager;
import java.util.Scanner;

public class StudentManager {
    private List<Student> students;

    public StudentManager() {
        this.students = new ArrayList<>();
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public void editStudent(String id, String name, double marks) {
    for (Student student : students) {
            if (student.getId().equals(id)) {
                student.setName(name);
                student.setMarks(marks);
                return;
            }
        }
         System.out.println("Student not found!");
    }

    public void deleteStudent(String id) {
        students.removeIf(student -> student.getId().equals(id));
    }

   public Student searchStudent(String id) {
    for (Student student : students) {
        if (student.getId().equals(id)) {
            return student;
        }
    }
    return null; 
}
   
    public void sortStudentsByMarks() {
            
            students.sort(Comparator.comparingDouble(Student::getMarks));
            System.out.println(students); // Print the sorted list of students
        }

    public void displayStudents() {
        for (Student student : students) {
            System.out.println(student);
        }
    }

    public static void main(String[] args) {
        StudentManager manager = new StudentManager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("----------- Student Management System -----------");
            System.out.println("1. Add New Student");
            System.out.println("2. Edit Student Info");
            System.out.println("3. Delete Student Info");
            System.out.println("4. Search Student Info");
            System.out.println("5. Sort Students by Marks");
            System.out.println("6. Display All Students in System");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter student ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Enter student name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter student marks: ");
                    double marks = scanner.nextDouble();
                    scanner.nextLine(); 
                    Student newStudent = new Student(id, name, marks);
                    manager.addStudent(newStudent);
                    System.out.println("Student added successfully.");
                    break;
                case 2:
                    System.out.print("Enter student ID to edit: ");
                    id = scanner.nextLine();
                    System.out.print("Enter new name: ");
                    name = scanner.nextLine();
                    System.out.print("Enter new marks: ");
                    marks = scanner.nextDouble();
                    scanner.nextLine(); 
                    manager.editStudent(id, name, marks);
                    break;
                case 3:
                    System.out.print("Enter student ID to delete: ");
                    id = scanner.nextLine();
                    manager.deleteStudent(id);
                    System.out.println("Student deleted successfully.");
                    break;
                case 4:
                    System.out.print("Enter student ID to search: ");
                    id = scanner.nextLine();
                    Student foundStudent = manager.searchStudent(id);
                    if (foundStudent != null) {
                        System.out.println("Student was found:");
                        System.out.println(foundStudent);
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;
                case 5: 
                    System.out.println("Students sorted by marks:");
                    manager.sortStudentsByMarks();
                    break;
                case 6:
                    System.out.println("List of Students:");
                    manager.displayStudents();
                    break;
                case 7:
                    System.out.println("Exiting program.");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 7.");
            }
        }
    }
    }

