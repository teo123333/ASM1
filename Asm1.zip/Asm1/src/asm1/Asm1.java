/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package asm1;

import java.util.Scanner;


/**
 *
 * @author Acer
 */
public class Asm1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in );
        System.out.println("Enter Student Name:");
        String name = scanner.nextLine();
        System.out.println("Enter Student age:");
        int age = scanner.nextInt();
        System.out.println("Enter Student learn subject:");
        String subject = scanner.nextLine();
        System.out.println("Enter subject marks:");
        int Marks = scanner.nextInt();
        System.out.println("hello " + name);
        System.out.println("their age is "+ age);
        System.out.println("subject " + subject);
        System.out.println("Marks " + Marks);

    }
    
}
